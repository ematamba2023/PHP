<?php
	//costanti con i parametri di connessione al database
	define("UTENTE","root");
	define("PASSWORD","");
	define("SERVER","localhost");
	define("DATABASE","piatti");
?>
