<html>
	<head>
		<title>Risulati</title>
		<link rel="stylesheet" href="stile.css">
	</head>
	<body>
		<h1>Genitori e figli </h1>
		<?php
			
			require("config.php"); 
			$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
			if ($mydb->connect_errno) {
				echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
				exit();  //termina la pagina
			}
			
            $nomeFiglio=$_POST["nome"];
            $cognomeFiglio=$_POST["cognome"];



            $query1 = "INSERT INTO figlio(nome, cognome) VALUES ("$nomeFiglio", "$cognomeFiglio")";
            $mydb->query($query1);
            $id_fig1=$mydb->insert_id;

			else{
				echo "<p>Non ci sono specifiche nel database.</p>";
			}
			
		?>
	</body>
</html>