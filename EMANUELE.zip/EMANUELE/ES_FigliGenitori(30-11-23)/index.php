<html>
	<head>
		<title>FORM</title>
		<link rel="stylesheet" href="stile.css">
	</head>
	<body>
		<h1>Genitori e Figli</h1>
		<?php

		

			require("config.php"); 
			$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
			if ($mydb->connect_errno) {
				echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
				exit();  //termina la pagina
			}

		?>
        <form method="post" action="genitori.php">
		<p>
                <label for="gen1">Genitore 1:</label> 
                <select name="gen1">

					<?php

					 $query1="SELECT *
					 			FROM genitori";

					$risultato1 = $mydb->query($query1);
					

						while($genitore = $risultato1->fetch_assoc()){
							echo "<option value='". $genitore["id"]."'>". $genitore["nome"]." ". $genitore["cognome"]."</option>";
						}
							
					?>
                </select>
				</p>
				<p>
				<label for="gen2">Genitore 2:</label> 
                <select name="gen2">

					<?php

					 $query2="SELECT *
					 			FROM genitori";

					$risultato2 = $mydb->query($query2);
					

						while($genitore = $risultato2->fetch_assoc()){
							echo "<option value='". $genitore["id"]."'>". $genitore["nome"]." ". $genitore["cognome"]."</option>";
						}
							
					?>
                </select>
					</p>

			Nome Figlio: <input type="text" id="nome" ><br></br>
			Cognome Figlio: <input type="text" id="cognome" ><br></br>
        
            <input type="submit" value="cerca">
        </form>
		

	</body>
</html>