<?php
    if(isset($_POST["bambino"])){
        /*instauro la connessione al database */
        require("config.php");  //file di config con i parametri di connessione
        $mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
        if ($mydb->connect_errno) {
            echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
            exit();  //termina la pagina
        }

        //inserire il bambino del database
        $query="INSERT INTO bambini (nome) VALUES ('".$_POST['bambino']."')";
        echo $query;
        $mydb->query($query);
        $id_bambino = $mydb->insert_id;
        $query="INSERT INTO giocattoli (nome, fkBambino) VALUES ('".$_POST['giocattolo1']."', ".$id_bambino."), ('".$_POST['giocattolo2']."', ".$id_bambino."), ('".$_POST['giocattolo3']."', ".$id_bambino.")";
        echo $query;
        $mydb->query($query);
    }


    