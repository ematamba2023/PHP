<?php
    if(isset($_POST["letterina"])){
        /*instauro la connessione al database */
        require("config.php");  //file di config con i parametri di connessione
        $mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
        if ($mydb->connect_errno) {
            echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
            exit();  //termina la pagina
        }

        //prima cancello i giocattoli
        $query="DELETE FROM giocattoli WHERE fkBambino = ".$_POST["letterina"];
        echo $query;
        $mydb->query($query);
        //poi cancello il bambino
        $query="DELETE FROM bambini WHERE id = ".$_POST["letterina"];
        echo $query;
        $mydb->query($query);
    }
?>