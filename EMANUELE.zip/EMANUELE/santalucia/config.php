<?php
    define("SERVER","localhost");
    define("UTENTE","root");
    define("PASSWORD","");
    define("DATABASE","santalucia");
?>