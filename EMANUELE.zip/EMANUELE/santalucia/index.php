<html>
    <head>
    </head>
    <body>
        <form action="inserisci.php" method="post">
            <p>Nome del bambino:<br><input type="text" name="bambino"></p>
            <p>Giocattoli desiderati:<br>
                <input type="text" name="giocattolo1"><br>
                <input type="text" name="giocattolo2"><br>
                <input type="text" name="giocattolo3"><br>
            </p>
            <input type="submit" name="invia" value="Manda la letterina">
        </form>
        <p>Elenco delle letterine già presenti</p>
        <?php
            /*instauro la connessione al database */
            require("config.php");  //file di config con i parametri di connessione
            $mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
            if ($mydb->connect_errno) {
                echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
                exit();  //termina la pagina
            }

            $query="SELECT id, nome FROM bambini";
            $risultati = $mydb->query($query);
            if($risultati->num_rows > 0){  
                echo "<form action='cancella.php' method='post'>";
                echo "<select name='letterina'>";
				while($letterina = $risultati->fetch_assoc()){
                    echo "<option value='".$letterina['id']."'>".$letterina['nome']."</option>";
                }
                echo "</select>";
                echo "<input type='submit' name='cancella' value='cancella'>";
                echo "</form>";
            }
            else{
                echo "<p>Non ci sono letterine</p>";
            }
        ?>
    </body>
</html>
