<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <form name="esempio1" action="script.php" method="post" enctype="multipart/form-data">
        <p>Nome: <input type="text" id="nome" name="nome"></p>
        <p>Cognome: <input type="text" id="cognome" name="cognome"></p>
        <input type="submit" value="Invia" name="invia">
    </form>
</body>
</html>