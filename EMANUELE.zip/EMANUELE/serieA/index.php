<!DOCTYPE html>
<body>
    <?php
    $squadre = array("Milan", "Inter", "Napoli", "Roma");
    foreach($squadre as $squadra){
        echo "<p>".$squadra."<p>";
    }
    ?>
    
</body>
</html>