<?php
session_start();
?>
<html>
	<head>
		<title>Esempio di registrazione</title>
	</head>
	<body>	
            <?php
                //gestione dei messaggi
                if(isset($_SESSION["registrato"]) && $_SESSION["registrato"]==true){
                    echo "<p>Registrazione effettuata con successo. Vai al <a href='login.php'>login</a></p>"
                }
                if(isset($_SESSION["errore_username"]) && $_SESSION["errore_username"]==true){
                    echo "<p>Lo username è già in uso. Scegline un altro.</p>"
                }
                if(isset($_SESSION["errore_password"]) && $_SESSION["errore_password"]==true){
                    echo "<p>Le password inserite non coincidono.</p>"
                }
            ?>
			<form id="registrazione" name="registrazione" method="post" action="registrazione.script.php">
				
				<label for="usr">Nome utente</label>
				<input type="text" placeholder="Inserisci username" name="usr" required>

				<label for="pwd">Password</label>
				<input type="password" placeholder="Inserisci password" name="pwd1" required>

                <label for="pwd">Ripeti la password</label>
				<input type="password" placeholder="Ripeti password" name="pwd2" required>

				<input type="submit" name="submit" value="Login">
			</form>
	
	</body>
</html>