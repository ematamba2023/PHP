<?php
session_start();
$_SESSION["errore_password"]=false; 
$_SESSION["errore_username"]=false; 
$_SESSION["registrato"]=false; 

if(isset($_POST["submit"])){
    if($_POST["pwd1"] == $_POST["pwd2"]){
        //se le password inserite sono uguali, controllo lo username
        //connessione al database
        require("config.php"); //parametri di connessione
        $mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
        if ($mydb->connect_errno) {
            echo "Errore nella connessione a MySQL: (" . $mydb->connect_errno . ") " . $mydb->connect_error;
            exit();
        }
        $stmt = $mydb->prepare("SELECT COUNT(id) AS num FROM utenti WHERE nome = (?)");
        //associo il parametro col tipo (s per stringa)
        $stmt->bind_param("s", $_POST["usr"]);
        //eseguo la query
        $stmt->execute();
        //associo i risultati a delle variabili (una variabile per campo)
        $stmt->bind_result($num);

        //fetch dei risultati
        while ($stmt->fetch()) { //eseguirà solo una iterazione
            if($num == 0){ //lo username non è utilizzato
                //faccio la insert
                $hash = password_hash($_POST["pwd1"], PASSWORD_DEFAULT);
                $stmt = $mydb->prepare("INSERT INTO utenti (nome, hash) VALUES (?,?)");
                $stmt->bind_param("ss", $_POST["usr"], $hash);
                $stmt->execute();
                $_SESSION["registrato"]=true; 
            }
            else{ //lo username è già in uso
                $_SESSION["errore_username"]=true; 
            }
        }
	//chiudo statement
	$stmt->close();
    }
    else{
        $_SESSION["errore_password"]=true; 
    }

}

//ritorna alla pagina invocante	
header("Location: registrazione.php");
exit();
?>