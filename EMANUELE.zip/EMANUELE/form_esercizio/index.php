<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form name="esempio1" action="script.php" method="post" enctype="multipart/form-data">
        <h1>Inserisci gli ingredienti dell'hamburger</h1>
        <p>Pane: <input type="text" id="pane" name="pane"></p>
        <p>Carne: <input type="text" id="carne" name="carne"></p>
        <p>Verdura: <input type="text" id="verdura" name="verdura"></p>
        <p>Formaggio: <input type="text" id="formaggio" name="formaggio"></p>
        <p>Salsa: <input type="text" id="salsa" name="salsa"></p>
        <p>Ingredienti extra: <input type="text" id="extra" name="extra"></p>
        <input type="submit" value="Invia" name="invia">
</body>
</html>