-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Nov 23, 2023 alle 20:54
-- Versione del server: 10.1.38-MariaDB
-- Versione PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2023-11-24_fila3`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `autore`
--

CREATE TABLE `autore` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `cognome` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `autore`
--

INSERT INTO `autore` (`id`, `nome`, `cognome`) VALUES
(1, 'Jane', 'Austen'),
(2, 'Charles', 'Dickens'),
(3, 'Leo', 'Tolstoy'),
(4, 'Emily', 'Brontë'),
(5, 'Mark', 'Twain'),
(6, 'Gabriel', 'García Márquez'),
(7, 'Virginia', 'Woolf'),
(8, 'F. Scott', 'Fitzgerald'),
(9, 'George', 'Orwell'),
(10, 'J.K.', 'Rowling');

-- --------------------------------------------------------

--
-- Struttura della tabella `editore`
--

CREATE TABLE `editore` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `editore`
--

INSERT INTO `editore` (`id`, `nome`) VALUES
(1, 'Penguin Random House'),
(2, 'HarperCollins'),
(3, 'Simon & Schuster'),
(4, 'Hachette Livre'),
(5, 'Macmillan Publishers');

-- --------------------------------------------------------

--
-- Struttura della tabella `libro`
--

CREATE TABLE `libro` (
  `id` int(11) NOT NULL,
  `titolo` varchar(30) DEFAULT NULL,
  `numPagine` int(11) DEFAULT NULL,
  `fkEditore` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `libro`
--

INSERT INTO `libro` (`id`, `titolo`, `numPagine`, `fkEditore`) VALUES
(1, 'Pride and Prejudice', 279, 1),
(2, 'Great Expectations', 544, 2),
(3, 'War and Peace', 1225, 3),
(4, 'Wuthering Heights', 384, 4),
(5, 'The Adventures of Tom Sawyer', 224, 5),
(6, 'One Hundred Years of Solitude', 417, 1),
(7, 'Mrs. Dalloway', 194, 2),
(8, 'The Great Gatsby', 180, 3),
(9, '1984', 328, 4),
(10, 'Harry Potter and the Wizard', 223, 5),
(11, 'Sense and Sensibility', 331, 1),
(12, 'A Tale of Two Cities', 448, 2),
(13, 'Anna Karenina', 964, 3),
(14, 'Jane Eyre', 532, 4),
(15, 'The Adventures of Huckleberry ', 366, 5),
(16, 'Love in the Time of Cholera', 348, 1),
(17, 'To the Lighthouse', 218, 2),
(18, 'The Catcher in the Rye', 277, 3),
(19, 'Animal Farm', 112, 4),
(20, 'Harry Potter and the Chamber', 251, 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `scrivere`
--

CREATE TABLE `scrivere` (
  `fkAutore` int(11) NOT NULL,
  `fkLibro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `scrivere`
--

INSERT INTO `scrivere` (`fkAutore`, `fkLibro`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 11),
(2, 2),
(2, 12),
(3, 3),
(3, 4),
(3, 5),
(3, 13),
(3, 14),
(4, 4),
(5, 5),
(5, 6),
(5, 15),
(6, 6),
(6, 7),
(6, 8),
(6, 16),
(7, 7),
(7, 17),
(8, 8),
(8, 9),
(8, 18),
(9, 1),
(9, 9),
(9, 10),
(9, 19),
(9, 20),
(10, 10);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `autore`
--
ALTER TABLE `autore`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `editore`
--
ALTER TABLE `editore`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `libro`
--
ALTER TABLE `libro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fkEditore` (`fkEditore`);

--
-- Indici per le tabelle `scrivere`
--
ALTER TABLE `scrivere`
  ADD PRIMARY KEY (`fkAutore`,`fkLibro`),
  ADD KEY `fkLibro` (`fkLibro`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `autore`
--
ALTER TABLE `autore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `editore`
--
ALTER TABLE `editore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `libro`
--
ALTER TABLE `libro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `libro`
--
ALTER TABLE `libro`
  ADD CONSTRAINT `libro_ibfk_1` FOREIGN KEY (`fkEditore`) REFERENCES `editore` (`id`);

--
-- Limiti per la tabella `scrivere`
--
ALTER TABLE `scrivere`
  ADD CONSTRAINT `scrivere_ibfk_1` FOREIGN KEY (`fkAutore`) REFERENCES `autore` (`id`),
  ADD CONSTRAINT `scrivere_ibfk_2` FOREIGN KEY (`fkLibro`) REFERENCES `libro` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
