<!DOCTYPE html>
<html lang="en">
<head>
<title>Libreria</title>
		<link rel="stylesheet" href="stile.css">
</head>
<body>
    <h1>Elenco Libri Editore: 
		<?php 
		 echo $_GET["editore"];
		?>
	</h1>

    <?php
            require("config.php"); 
			$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
			if ($mydb->connect_errno) {
				echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
				exit();  //termina la pagina
			}
	?>

	<?php

		if(isset($_GET['editore'])){

            $editore=$_GET["editore"];
				$query2 = "SELECT l.titolo, l.numPagine, a.nome AS NumAutore
				FROM libro l
				JOIN editore e ON e.id = l.fkeditore
				JOIN scrivere s ON l.id = s.fkLibro
				JOIN autore a ON a.id = s.fkAutore
				WHERE e.nome ='".$editore."'
            ";
			$risultato1 = $mydb->query($query2);

            if($risultato1->num_rows > 0){  
                echo "<table>";
                echo "<tr>
						<td>Titolo</td>
						<td>Pagine</td>
						<td>Autore</td>
						</tr>";

				//stampo le singole righe della tabella
				while($Libri_Editore = $risultato1->fetch_assoc()){
					echo "<tr>";
					echo "<td>".$Libri_Editore["titolo"]."</td>";
					echo "<td>".$Libri_Editore["numPagine"]."</td>";
					echo "<td>".$Libri_Editore["NumAutore"]."</td>";
					echo "</tr>";
				}
                echo "</table>";
			}
			else{
				echo "<p>Non ci sono specifiche nel database.</p>";
			}
		}
		else{
			$query_e ="	SELECT *
					FROM libro
					";
		$risultato2 = $mydb->query($query_e);

		if($risultato2->num_rows > 0){  
			echo "<table>";
			echo "<tr>

			<td>Nome</td>

			</tr>";
			
			while($libri = $risultato2->fetch_assoc()){
						echo "<tr>";
						echo "<td>".$libri["titolo"]."</td>";
						echo "</tr>";	
			}
			echo "</table>";
		}
		else{
			echo "<p>Non ci sono specifiche nel database.</p>";
		}
	
}	
?>


    
</body>
</html>