<html>
	<head>
		<title>Libreria</title>
		<link rel="stylesheet" href="stile.css">
	</head>
	<body>
		<h1>Liberia</h1>
        <h2>Elenco Editori</h2>
		<?php
			
			require("config.php"); 
			$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
			if ($mydb->connect_errno) {
				echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
				exit();  //termina la pagina
			}

		
			$query1 = "SELECT a.nome AS nome_autore, COUNT( * ) AS N_libri
			FROM autore a
			JOIN scrivere s ON a.id = s.fkAutore
			JOIN libro l ON l.id = s.fkLibro
			GROUP BY a.nome
			ORDER BY N_libri";
			$risultato1 = $mydb->query($query1);
			
			
			if($risultato1->num_rows > 0){  
                echo "<table>";
                echo "<tr><td>Nome</td><td>Libri Scritti</td></tr>";
				
				while($Autore  = $risultato1->fetch_assoc()){
							echo "<tr>";
							echo "<td>";
                                echo $Autore ["nome_autore"];
                            echo "</td>";
							echo "<td>";
                                echo $Autore ["N_libri"];
                            echo "</td>";
							echo "</tr>";	
				}
                echo "</table>";
			}
			else{
				echo "<p>Non ci sono Libri al interno database.</p>";
			}
		
		?>

		<form action="ricerca.php" method="POST">
            <p>
                <label for="Pag_MIN">Numero pagine Minime:</label> 
                <input type="number" name="Pag_MIN">
                <br>
                <label for="Pag_MAX">Numero pagine Massime:</label> 
                <input type="number" name="Pag_MAX">
            </p>
            <input type="submit" value="Invia" name="invia">




		

	</body>
</html>