<?php 
   
		require("config.php");  
		$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
		if ($mydb->connect_errno) {
			echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
			exit();  
		}
			
		//query per cercare le auto sulla base dei parametri
		$query1 = "SELECT * FROM libro ";
        //controllo se almeno un parametro è stato "selezionato"
        if(($_POST["Pag_MIN"]!="" && $_POST["Pag_MAX"]!="")){
                $query1 = $query1." WHERE ";

                if($_POST["Pag_MIN"]!="" && $_POST["Pag_MAX"]!=""){
                    
                    $query1 .= " numPagine>= ".$_POST["Pag_MIN"]." AND numPagine <= ".$_POST["Pag_MAX"]." AND ";
                }
               
                $query1 = substr($query1, 0, -4); //elimino gli ultimi 4 caratteri (AND )
        
		$risultato1 = $mydb->query($query1);
			
        if($risultato1->num_rows > 0){  
            echo "<table>";
            echo "<tr>
                    <td>Titolo</td>
                    </tr>";

            //stampo le singole righe della tabella
            while($range_libri = $risultato1->fetch_assoc()){
                echo "<tr>";
                echo "<td>".$range_libri["titolo"]."</td>";
    
            }
            echo "</table>";
        }
        else{
            echo "<p>Non ci sono specifiche nel database.</p>";
        }
        
    }
    
?>
    </body>
</html>
            