<html>
	<head>
		<title>Libreria</title>
		<link rel="stylesheet" href="stile.css">
	</head>
	<body>
		<h1>Elenco Libri</h1>
		<?php
			/*instauro la connessione al database */
			require("config.php");  //file di config con i parametri di connessione
			$mydb = new mysqli(SERVER, UTENTE, PASSWORD, DATABASE);
			if ($mydb->connect_errno) {
				echo "Errore nella connessione a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
				exit();  //termina la pagina
			}
			
			
			
			
			
				
					$query1="SELECT l.titolo, l.numPagine, e.nome AS NumEditore, a.nome AS NumAutore
					FROM libro l
					JOIN editore e ON l.fkeditore = e.id
					JOIN scrivere s ON l.id = s.fkLibro
					JOIN autore a ON a.id = s.fkAutore
					ORDER BY l.numPagine
					LIMIT 0 , 30 ";
					
					$risultato1 = $mydb->query($query1);

					
					if($risultato1->num_rows > 0){ 

						
						echo "<table>";
						echo "<tr>
							<td>Titolo</td>
							<td>Pagine</td>
							<td>editore</td>
							<td>Autore</td>
							</tr>";

						//stampo le singole righe della tabella
						while($Elencolibri = $risultato1->fetch_assoc()){
							echo "<tr>";
							echo "<td>".$Elencolibri["titolo"]."</td>";
							echo "<td>".$Elencolibri["numPagine"]."</td>";
							echo "<td>".$Elencolibri["NumEditore"]."</td>";
							echo "<td>".$Elencolibri["NumAutore"]."</td>";
							echo "</tr>";
						}
						echo "</table>";
					}
					else{
						echo "<p>Non risultano Libri al interno dal database.</p>";
					}
					
		?>
	</body>
</html>